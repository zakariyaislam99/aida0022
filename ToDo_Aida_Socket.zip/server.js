const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const fs = require('fs');
const path = require('path');

const DATA_FILE = path.join(__dirname, 'data.json');
function loadData(){ try{ return JSON.parse(fs.readFileSync(DATA_FILE,'utf8')||'[]'); }catch(e){ return []; } }
function saveData(tasks){ try{ fs.writeFileSync(DATA_FILE, JSON.stringify(tasks, null, 2)); }catch(e){ console.error('save error',e); } }

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

app.use(express.static(path.join(__dirname, 'public')));

let tasks = loadData();

io.on('connection', (socket) => {
  console.log('client connected', socket.id);
  socket.emit('init', tasks);

  socket.on('add', (task) => {
    tasks.unshift(task);
    saveData(tasks);
    io.emit('added', task);
  });

  socket.on('toggle', ({ id }) => {
    tasks = tasks.map(t => t.id === id ? { ...t, done: !t.done } : t);
    saveData(tasks);
    io.emit('updated', { id, patch: tasks.find(t=>t.id===id) || {} });
  });

  socket.on('edit', ({ id, text }) => {
    tasks = tasks.map(t => t.id === id ? { ...t, text } : t);
    saveData(tasks);
    io.emit('updated', { id, patch: tasks.find(t=>t.id===id) || {} });
  });

  socket.on('delete', ({ id }) => {
    tasks = tasks.filter(t => t.id !== id);
    saveData(tasks);
    io.emit('deleted', id);
  });

  socket.on('clearCompleted', () => {
    tasks = tasks.filter(t => !t.done);
    saveData(tasks);
    io.emit('init', tasks);
  });

  socket.on('checkAll', () => {
    tasks = tasks.map(t => ({ ...t, done: true }));
    saveData(tasks);
    io.emit('init', tasks);
  });

  socket.on('disconnect', () => {
    console.log('client disconnected', socket.id);
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log('Server listening on', PORT));
