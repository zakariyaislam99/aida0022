ToDo для Аиды — Socket.io real-time demo

How to run locally:
1. Install Node.js (>=14) and npm.
2. Extract this archive.
3. In the folder, run:
   npm install
   npm start
4. Open http://localhost:3000 in browser. Share this URL with others on your LAN or deploy to a server.

Notes:
- Tasks are stored in data.json (server-side). Multiple clients see the same tasks in real-time.
- This is a demo. For production, secure the server, add authentication, and use a proper DB.
